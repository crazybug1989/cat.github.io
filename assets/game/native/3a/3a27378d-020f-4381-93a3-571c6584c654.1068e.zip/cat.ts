import { db } from "../../../../framework/db/db";
import { platform } from "../../../../framework/plugin/platform/platform";
import { utilBundle } from "../../../../framework/plugin/utils/utilBundle";
import catSubPart from "./catSubPart";

const {ccclass, property} = cc._decorator;

@ccclass
export default class cat extends cc.Component 
{
    /**
     * 部件零件节点
     */
    @property(cc.Node)
    subPartPrefab: cc.Node = null;

    /**
     * 记录分组的选择
     */
    protected partMap: {[groupId: string]: string[]} = {};

    onLoad()
    {
        this.init();
    }
    
    onEnable()
    {
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStartHandler, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMoveHandler, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEndHandler, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancelHandler, this);
    }

    onDisable()
    {
        this.node.off(cc.Node.EventType.TOUCH_START, this.onTouchStartHandler, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMoveHandler, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this.onTouchEndHandler, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancelHandler, this);
    }

    /**
     * 触屏
     * @param event 
     */
    protected onTouchStartHandler(event: cc.Event.EventTouch) : void
    {

    }
    
    /**
     * 触屏
     * @param event 
     */
    protected onTouchMoveHandler(event: cc.Event.EventTouch) : void
    {

    }

    /**
     * 触屏
     * @param event 
     */
    protected onTouchEndHandler(event: cc.Event.EventTouch) : void
    {
        
    }

    /**
     * 触屏
     * @param event 
     */
    protected onTouchCancelHandler(event: cc.Event.EventTouch) : void
    {

    }

    /**
     * 初始化
     */
    public init() : void
    {
        for (let i = 0; i < db.game.common.initParts.length; i++)
        {
            this.addPart(db.game.common.initParts[i]);
        }
    }

    /**
     * 用数据初始化
     * @param data 
     */
    public initWithData(data: any) : void
    {

    }

    /**
     * 清除所有部件
     */
    public clear() : void
    {
        for (let gid in this.partMap)
        {
            this.clearGroup(gid);
        }
    }

    /**
     * 清除分组
     * @param groupId 
     */
    public clearGroup(groupId: string) : void
    {
        if (!this.partMap[groupId])
        {
            return;
        }

        for (let i = 0; i < this.partMap[groupId].length; i++)
        {
            this.clearPart(this.partMap[groupId][i]);
        }
    }

    /**
     * 清除部件
     * @param partId 
     */
    public clearPart(partId: string) : void
    {
        let partDB = db.game.part[partId];
        if (!partDB.crashEnable)
        {
            platform.instance.showToast('关键组件只能替换不可移除');
            return;
        }

        for (let i = 0; i < partDB.resources.length; i++)
        {
            cc.find(partDB.resources[i][0], this.node).removeAllChildren();
        }

        if (!this.partMap[partDB.groupId])
        {
            return;
        }

        let gIndex = this.partMap[partDB.groupId].indexOf(partId);
        if (gIndex !== -1)
        {
            this.partMap[partDB.groupId].splice(gIndex, 1);
            if (this.partMap[partDB.groupId].length === 0)
            {
                delete this.partMap[partDB.groupId];
            }
        }
    }

    /**
     * 添加一个部件零件
     * @param id 
     */
    public addSubPart(id: string) : void
    {
        let subPart = cc.instantiate(this.subPartPrefab).getComponent(catSubPart);
        subPart.init(id);
        // 父节点
        let pNode = cc.find(subPart.data.nodeUrl, this.node);
        if (!pNode)
        {
            console.error('父节点查找失败');
            return;
        }
        pNode.addChild(subPart.node);
    }

    /**
     * 设置部件
     * @param partId 
     */
    public addPart(partId: string) : void
    {
        if (partId === '')
        {
            return;
        }

        let partDB = db.game.part[partId];
        // 设置
        for (let i = 0; i < partDB.resources.length; i++)
        {
            // 节点名字
            let nodeUrl = partDB.resources[i][0];
            // 资源路径
            let resUrl = partDB.resources[i][1];
            // 位置
            let posArr = partDB.resources[i][2].split(',');
            let position = [parseFloat(posArr[0]), parseFloat(posArr[1])];

            console.log(nodeUrl);
            // 查找节点
            let pNode = cc.find(nodeUrl, this.node);

            let part: cc.Node = null;
            if (pNode.childrenCount < partDB.maxCount)
            {
                // 添加节点
                part = cc.instantiate(this.partPrefab);
                // part.getComponent(cc.Sprite).srcBlendFactor = cc.macro.BlendFactor.ONE;
                pNode.addChild(part);

                if (!this.partMap[partDB.groupId])
                {
                    this.partMap[partDB.groupId] = [];
                }
                this.partMap[partDB.groupId].push(partId);
            }
            else
            {
                // 替换掉第一个
                part = pNode.children[0];
                // 替换将部件放到末尾
                part.setSiblingIndex(pNode.childrenCount - 1);

                this.partMap[partDB.groupId].shift();
                this.partMap[partDB.groupId].push(partId);
            }

            // 设置位置
            part.setPosition(cc.v2(position[0], position[1]));
            // 加载资源
            utilBundle.instance.loadBundleRes('game', cc.SpriteFrame, 'textures/items/' + resUrl).then((res: cc.SpriteFrame) => {
                // res.getTexture().setPremultiplyAlpha(true);
                part.getComponent(cc.Sprite).spriteFrame = res;
            });
        }
    }

    /**
     * 播放摇头动画
     */
    public playAnimation() : void
    {
        this.node.getChildByName('node').getChildByName('face').getComponent(cc.Animation).play();
    }

    /**
     * 停止摇头动画
     */
    public stopAnimation() : void
    {
        this.node.getChildByName('node').getChildByName('face').angle = 0;
        this.node.getChildByName('node').getChildByName('face').getComponent(cc.Animation).stop();
    }

    /**
     * 展示状态
     */
    public viewState() : void
    {
        this.node.getChildByName('node').runAction(cc.moveTo(0.2, cc.v2(0, -120)));
    }

    /**
     * 装扮状态
     */
    public makeState() : void
    {
        this.node.getChildByName('node').runAction(cc.moveTo(0.2, cc.v2(0, 0)));
    }
}
